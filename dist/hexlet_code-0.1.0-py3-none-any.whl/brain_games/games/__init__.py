# Games facade

import brain_games.games.brain_even
import brain_games.games.brain_calc
import brain_games.games.brain_gcd
import brain_games.games.brain_progression
import brain_games.games.brain_prime


__all__ = (
    'brain_even',
    'brain_calc',
    'brain_gcd',
    'brain_progression',
    'brain_prime',
)
