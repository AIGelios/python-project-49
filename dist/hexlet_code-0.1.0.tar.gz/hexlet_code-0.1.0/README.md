### Hexlet tests and linter status:
[![Actions Status](https://github.com/AIGelios/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AIGelios/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/e17bf6116ad45b2606ed/maintainability)](https://codeclimate.com/github/AIGelios/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/e17bf6116ad45b2606ed/test_coverage)](https://codeclimate.com/github/AIGelios/python-project-49/test_coverage)

### ASCIInemas of package installation and all games::
https://asciinema.org/a/1zhe4Ou0ymyKJpZJckClZd1lB
https://asciinema.org/a/1XuFWc3qHb0PVlz2L9FYYWxJv
https://asciinema.org/a/LBFU4dcDVqI22qy27hg8jKSZX
https://asciinema.org/a/AFb1JTc9wYgMQoo22lZ9UsctS
https://asciinema.org/a/YWER6ryqinTMLSzrmHI5FtKh6
