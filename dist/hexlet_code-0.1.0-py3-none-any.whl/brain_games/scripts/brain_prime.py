#!/usr/bin/env
from brain_games.shell import game_shell as run
import brain_games.games.prime as game


def main():
    '''Run the game "Prime or not"'''
    run(game)


if __name__ == '__main__':
    main()
