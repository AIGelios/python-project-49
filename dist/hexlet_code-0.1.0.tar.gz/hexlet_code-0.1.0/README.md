### Hexlet tests and linter status:
[![Actions Status](https://github.com/AIGelios/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AIGelios/python-project-49/actions)

### ASCIInema of package installation and brain-even game:
https://asciinema.org/a/1zhe4Ou0ymyKJpZJckClZd1lB

### ASCIInema of brain-calc game:
https://asciinema.org/a/1XuFWc3qHb0PVlz2L9FYYWxJv

### ASCIInema of brain-gcd game:
https://asciinema.org/a/LBFU4dcDVqI22qy27hg8jKSZX
