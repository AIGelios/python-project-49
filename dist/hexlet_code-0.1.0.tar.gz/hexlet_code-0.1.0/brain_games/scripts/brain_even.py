#!/usr/bin/env
import brain_games.shell as shell
import brain_games.games.even as game


def main():
    shell.game_shell(game)


if __name__ == '__main__':
    main()
